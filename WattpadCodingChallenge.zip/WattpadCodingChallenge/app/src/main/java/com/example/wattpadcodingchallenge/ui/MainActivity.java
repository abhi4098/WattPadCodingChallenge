package com.example.wattpadcodingchallenge.ui;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;

import com.example.wattpadcodingchallenge.R;
import com.example.wattpadcodingchallenge.db.StoryModel;
import com.example.wattpadcodingchallenge.viewModel.GetStoryViewModel;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private GetStoryViewModel getStoryViewModel;
    private RecyclerViewAdapter recyclerViewAdapter;
    private RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

       recyclerView = findViewById(R.id.recyclerView);
       recyclerViewAdapter = new RecyclerViewAdapter(new ArrayList<StoryModel>());
       recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(recyclerViewAdapter);

        getStoryViewModel = ViewModelProviders.of(this).get(GetStoryViewModel.class);
        getStoryViewModel.getStoryList().observe(MainActivity.this, new Observer<List<StoryModel>>() {
            @Override
            public void onChanged(List<StoryModel> storyModels) {

                    recyclerViewAdapter.addItems(storyModels);                }

        });

    }
}
