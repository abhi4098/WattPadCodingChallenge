package com.example.wattpadcodingchallenge.ui;


import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.wattpadcodingchallenge.R;
import com.example.wattpadcodingchallenge.db.StoryModel;



import java.util.List;

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.RecyclerViewHolder> {

    private List<StoryModel> StoryModelList;
    private View.OnLongClickListener longClickListener;

    public RecyclerViewAdapter(List<StoryModel> StoryModelList) {
        this.StoryModelList = StoryModelList;

    }


    @Override
    public RecyclerViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new RecyclerViewHolder(LayoutInflater.from(parent.getContext())
                .inflate(R.layout.recycler_item, parent, false));
    }

    @Override
    public void onBindViewHolder(final RecyclerViewHolder holder, int position) {
        StoryModel StoryModel = StoryModelList.get(position);
        holder.itemTextView.setText(StoryModel.getTitle());
        holder.nameTextView.setText(StoryModel.getUserName());
        holder.itemView.setTag(StoryModel);

    }

    @Override
    public int getItemCount() {
        return StoryModelList.size();
    }

    public void addItems(List<StoryModel> StoryModelList) {
        this.StoryModelList = StoryModelList;
        notifyDataSetChanged();
    }

    static class RecyclerViewHolder extends RecyclerView.ViewHolder {
        private TextView itemTextView;
        private TextView nameTextView;


        RecyclerViewHolder(View view) {
            super(view);
            itemTextView = view.findViewById(R.id.itemTextView);
            nameTextView = view.findViewById(R.id.nameTextView);

        }
    }
}