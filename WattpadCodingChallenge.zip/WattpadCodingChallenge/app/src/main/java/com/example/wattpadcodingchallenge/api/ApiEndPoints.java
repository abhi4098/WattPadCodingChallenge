package com.example.wattpadcodingchallenge.api;


public class ApiEndPoints {

        public static String BASE_URL = "https://www.wattpad.com/";

        // https://www.wattpad.com/api/v3/stories?fields=stories%28id%2Ctitle%2Ccover%2Cuser%29&filter=new&limit=10&offset=10

}



