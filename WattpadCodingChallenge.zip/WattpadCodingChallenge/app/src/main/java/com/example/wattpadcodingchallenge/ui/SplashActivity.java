package com.example.wattpadcodingchallenge.ui;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;


import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProviders;

import com.example.wattpadcodingchallenge.R;
import com.example.wattpadcodingchallenge.api.ApiAdapter;
import com.example.wattpadcodingchallenge.api.RetrofitInterface;
import com.example.wattpadcodingchallenge.db.StoryModel;
import com.example.wattpadcodingchallenge.generated.model.Story;
import com.example.wattpadcodingchallenge.generated.model.StoryFeed;
import com.example.wattpadcodingchallenge.utils.LoadingDialog;
import com.example.wattpadcodingchallenge.utils.NetworkUtils;
import com.example.wattpadcodingchallenge.viewModel.AddStoryViewModel;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.example.wattpadcodingchallenge.api.ApiEndPoints.BASE_URL;


public class SplashActivity extends AppCompatActivity {

    Context mContext;
    AddStoryViewModel addStoryViewModel;

    private RetrofitInterface.StroryFeedClient StoryFeedAdapter;
   // ArrayList<StoryFeed> teamListData;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_splash);
        mContext = SplashActivity.this;
        addStoryViewModel = ViewModelProviders.of(this).get(AddStoryViewModel.class);
        calltoSplash();
    }


    public void calltoSplash() {
        LoadData();
    }


    private void LoadData() {
        setUpRestAdapter();
        getTeamsList();
    }

    private void getTeamsList() {
        LoadingDialog.showLoadingDialog(this,"Sync Data...");
        Call<StoryFeed> call = StoryFeedAdapter.storyFeedList();
        if (NetworkUtils.isNetworkConnected(this)) {
            call.enqueue(new Callback<StoryFeed>() {

                @Override
                public void onResponse(Call<StoryFeed> call, Response<StoryFeed> response) {
                    if (response.isSuccessful()) {

                        saveTeamListData(response);


                        LoadingDialog.cancelLoading();
                    }
                }

                @Override
                public void onFailure(Call<StoryFeed> call, Throwable t) {


                    LoadingDialog.cancelLoading();
                }


            });


        }
        else {
            openNextActivity();

            LoadingDialog.cancelLoading();
        }
    }

    private void saveTeamListData(Response<StoryFeed> response) {
       Log.e("abhi", "saveTeamListData: ..............." +response.body().getStories().size());
       List<Story> storyResponse = response.body().getStories();

       for(int i=0; i< storyResponse.size(); i++) {



           addStoryViewModel.addStory( new StoryModel(
                   storyResponse.get(i).getTitle(),
                   storyResponse.get(i).getUser().getName(),
                   storyResponse.get(i).getUser().getAvatar(),
                   storyResponse.get(i).getCover()
           ));
       }

        openNextActivity();
    }

    private void openNextActivity() {
        Intent i = new Intent(SplashActivity.this, MainActivity.class);

        startActivity(i);
        finish();
    }

    private void setUpRestAdapter() {
        StoryFeedAdapter = ApiAdapter.createRestAdapter(RetrofitInterface.StroryFeedClient.class, BASE_URL, this);

    }

}


